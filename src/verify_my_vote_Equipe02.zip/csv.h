#ifndef CSV_H
#define CSV_H

#include "structures.h"

void lecture_csv(char* nom_fichier, votant* votants[MAX_VOTANTS], vote* votes[MAX_VOTES]);

#endif // CSV_H
